# Pogglot - área de membros (backend)

Sem configuração, o app roda em modo **demo** (dados só no navegador). Para login real de alunos, use o Supabase (plano gratuito basta).

## Passo a passo

1. Crie uma conta em supabase.com e um **New project** (anote a senha do banco; não é usada no app).
2. No menu **SQL Editor**, cole todo o conteúdo de `backend/schema.sql` e clique em **Run**. Isso cria as tabelas, índices e regras de segurança (RLS).
3. Em **Authentication > Providers > Email**, desligue **Confirm email** para o aluno entrar logo após o cadastro.
   - Se deixar ligado: o cadastro funciona, mas o aluno precisa clicar no link recebido por e-mail antes de entrar (o app avisa isso). O envio padrão do Supabase tem limite baixo de e-mails por hora; para muitos alunos configure um SMTP próprio.
4. Em **Authentication > URL Configuration**, ponha o endereço do seu site em **Site URL** (usado nos links de recuperação de senha).
5. Em **Project Settings > API**, copie **Project URL** e a chave **anon public**. Cole em `config.js`:
   ```js
   window.POGGLOT_CONFIG={supabaseUrl:'https://xxxx.supabase.co',supabaseAnonKey:'eyJ...'};
   ```
   Use só a anon key (ela é pública por desenho; a proteção vem do RLS). Nunca a `service_role`.
6. Hospede os arquivos (`index.html`, `js/`, `config.js` etc.) em qualquer hospedagem estática (Netlify, Cloudflare Pages, GitHub Pages, seu próprio site). Precisa de HTTPS.

## Moderação

Denúncias ficam na tabela `reports` (Table Editor do Supabase). Para remover uma mensagem, apague a linha em `messages`. Para banir um aluno, apague-o em Authentication > Users (o perfil e as mensagens somem junto).

## Limitações

- **XP, sequência e episódios são autodeclarados** pelo navegador: um aluno técnico pode forjar o ranking. Para endurecer, use uma Edge Function (veja o comentário no `schema.sql`).
- Moderação básica: só denúncia + bloqueio individual; sem filtro automático de palavras.
- Chat por consulta periódica (a cada ~3 s com a aba aberta); **sem push** nem notificações com o app fechado.
- Dados do modo demo ficam só no navegador e não são seguros (senha com hash simples).
