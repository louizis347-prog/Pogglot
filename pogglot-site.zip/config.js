/* Configuração da área de membros do Pogglot.
 * Deixe vazio para usar o modo DEMO (dados só neste navegador).
 * Para login real: cole a URL do projeto e a chave "anon public" do Supabase
 * (Project Settings > API). Nunca coloque a chave service_role aqui. */
window.POGGLOT_CONFIG={supabaseUrl:'',supabaseAnonKey:''};
