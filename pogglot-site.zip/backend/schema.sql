-- Pogglot - schema do Supabase (cole no SQL Editor e execute uma vez).
-- NOTA: xp, streak, eps e ach vêm do CLIENTE (autodeclarados): não é à prova de fraude.
-- Para endurecer depois: remova a policy de update direto em profiles para essas colunas
-- (ou use column privileges) e crie uma Edge Function que valide a atividade
-- (ex.: episódios concluídos) e grave os números com a service_role.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text check (char_length(name) <= 40),
  avatar text check (char_length(avatar) <= 16),
  native text,
  learning text[] default '{}',
  bio text check (char_length(bio) <= 300),
  xp int not null default 0,
  streak int not null default 0,
  eps jsonb not null default '{}',
  ach jsonb not null default '{}',
  updated_at timestamptz default now()
);

create table if not exists public.messages (
  id bigint generated always as identity primary key,
  room text not null,
  uid uuid not null references public.profiles(id) on delete cascade,
  text text not null check (char_length(text) between 1 and 1000),
  fix_of bigint null references public.messages(id) on delete set null,
  created_at timestamptz default now()
);

create table if not exists public.reports (
  id bigint generated always as identity primary key,
  msg_id bigint references public.messages(id) on delete cascade,
  reporter uuid references public.profiles(id) on delete cascade,
  reason text check (char_length(reason) <= 300),
  created_at timestamptz default now()
);

create table if not exists public.blocks (
  blocker uuid not null references public.profiles(id) on delete cascade,
  blocked uuid not null references public.profiles(id) on delete cascade,
  primary key (blocker, blocked)
);

create index if not exists messages_room_id_idx on public.messages (room, id);
create index if not exists profiles_xp_idx on public.profiles (xp desc);

-- DM: room = 'dm:' || menorUUID || ':' || maiorUUID. O usuário precisa ser um dos dois ids.
create or replace function public.is_dm_member(room text)
returns boolean language sql stable as $$
  select split_part(room, ':', 1) = 'dm'
     and (select auth.uid())::text in (split_part(room, ':', 2), split_part(room, ':', 3));
$$;

alter table public.profiles enable row level security;
alter table public.messages enable row level security;
alter table public.reports  enable row level security;
alter table public.blocks   enable row level security;

-- profiles
create policy "profiles_select" on public.profiles for select to authenticated using (true);
create policy "profiles_insert" on public.profiles for insert to authenticated with check (id = (select auth.uid()));
create policy "profiles_update" on public.profiles for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));
create policy "profiles_delete" on public.profiles for delete to authenticated using (id = (select auth.uid()));

-- messages: salas públicas (não começam com 'dm:') ou DM da qual o usuário faz parte
create policy "messages_select" on public.messages for select to authenticated
  using (room not like 'dm:%' or public.is_dm_member(room));
create policy "messages_insert" on public.messages for insert to authenticated
  with check (uid = (select auth.uid()) and (room not like 'dm:%' or public.is_dm_member(room)));
create policy "messages_delete" on public.messages for delete to authenticated using (uid = (select auth.uid()));

-- reports: só inserir (a leitura é pelo painel do Supabase, com a service_role)
create policy "reports_insert" on public.reports for insert to authenticated with check (reporter = (select auth.uid()));

-- blocks: CRUD do próprio usuário
create policy "blocks_select" on public.blocks for select to authenticated using (blocker = (select auth.uid()));
create policy "blocks_insert" on public.blocks for insert to authenticated with check (blocker = (select auth.uid()));
create policy "blocks_update" on public.blocks for update to authenticated
  using (blocker = (select auth.uid())) with check (blocker = (select auth.uid()));
create policy "blocks_delete" on public.blocks for delete to authenticated using (blocker = (select auth.uid()));
